﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="calendar-en.min.js" />
/// <reference path="jquery-1.10.2.js" />
/// <reference path="jquery-1.4.1.js" />
/// <reference path="jquery.dyndatetime.min.js" />
/// <reference path="modernizr-2.6.2.js" />
/// <reference path="respond.js" />
