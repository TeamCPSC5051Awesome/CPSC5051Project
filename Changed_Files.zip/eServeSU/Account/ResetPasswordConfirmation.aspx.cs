﻿using System.Web.UI;

namespace eServeSU.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}