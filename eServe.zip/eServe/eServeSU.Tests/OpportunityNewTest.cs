﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using eServeSU;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace eServeSU.Tests
{
    [TestClass]
    public class OpportunityNewTest
    {
        public TestContext TestContext { get; set; }
        public string ConnectionString = ConfigurationManager.ConnectionStrings["eServeConnection"].ConnectionString;

        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_GetAllOpportunity()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(*) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            //Opportunity
            Opportunity opp = new Opportunity();
            List<Opportunity> oppList = opp.GetAllOpportunities();
            Assert.AreEqual(oppCount, oppList.Count);
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_SqlConnectionNull()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);

            try 
            {
                sqlConnection.Open();
            }
            catch
            {
                Assert.Fail();
            }

        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_NoOpportunities()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(*) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            if (oppCount == 0)
                Assert.Fail("NO OPPORTUNITIES LISTED!");
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_CheckStatus()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(status) from opportunity where status='pending'", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            //Opportunity
            int count=0;
            int statusCount = 0;
            Opportunity opp = new Opportunity();
            List<Opportunity> oppList = opp.GetAllOpportunities();
            while(count <oppList.Count)
            {
                if(oppList[count].Status.Equals("pending"))
                    statusCount++;
                count++;
            }

            Assert.AreEqual(oppCount, statusCount);
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_NumberOfCommunityPartners()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(DISTINCT CPID) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            var cpCommand = new SqlCommand("select count(*) from communitypartners", sqlConnection);
            var cpCount = Convert.ToInt32(cpCommand.ExecuteScalar());

            Assert.AreEqual(oppCount, cpCount);
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_NumberOfQuarters()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(DISTINCT quarterid) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            var cpCommand = new SqlCommand("select count(*) from quarter", sqlConnection);
            var cpCount = Convert.ToInt32(cpCommand.ExecuteScalar());

            if (oppCount > cpCount)
                Assert.Fail();
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_NumberOfTypes()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(DISTINCT typeid) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            var cpCommand = new SqlCommand("select count(*) from opportunitytype", sqlConnection);
            var cpCount = Convert.ToInt32(cpCommand.ExecuteScalar());

            if (oppCount > cpCount)
                Assert.Fail();

        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_NumberOfCommunityPartnerPeople()
        {
            //Initialize SqlQueryHelper object
            var sqlConnection = new SqlConnection(ConnectionString);
            sqlConnection.Open();

            var command = new SqlCommand("select count(DISTINCT cppid) from opportunity", sqlConnection);
            var oppCount = Convert.ToInt32(command.ExecuteScalar());

            var cpCommand = new SqlCommand("select count(*) from communitypartnerspeople", sqlConnection);
            var cpCount = Convert.ToInt32(cpCommand.ExecuteScalar());

            if (oppCount > cpCount)
                Assert.Fail();
        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_CheckDates()
        {
            //Opportunity
            int count = 0;
            Opportunity opp = new Opportunity();
            List<Opportunity> oppList = opp.GetAllOpportunities();
            
            while(count <oppList.Count())
            {
                if (DateTime.Now < oppList[count].OrientationDate)
                    Assert.Fail();
                count++;
            }

        }
        [TestMethod]
        [TestCategory("OpportunityNew")]
        [Description("")]
        public void Test_CheckApprovalToOrientationDates()
        {
            //Opportunity
            int count = 0;
            Opportunity opp = new Opportunity();
            List<Opportunity> oppList = opp.GetAllOpportunities();

            while (count < oppList.Count())
            {
                if (oppList[count].DateApproved > oppList[count].OrientationDate)
                    Assert.Fail();
                count++;
            }

        }
    }
}

