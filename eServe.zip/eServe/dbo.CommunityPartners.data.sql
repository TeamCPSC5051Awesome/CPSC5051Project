﻿SET IDENTITY_INSERT [dbo].[CommunityPartners] ON
INSERT INTO [dbo].[CommunityPartners] ([CPID], [OrganizationName], [Address], [Website], [MainPhone], [MissionStatement], [WorkDescription]) VALUES (1, 'Habitat For Humanity', 'Seattle, WA', 'www.seattleu.edu','5555555555', NULL, NULL)
SET IDENTITY_INSERT [dbo].[CommunityPartners] OFF
