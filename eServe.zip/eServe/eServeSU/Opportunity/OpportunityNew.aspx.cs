﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace eServeSU
{
    public partial class Opportunity_OpportunityNew : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataBind();
                Session["OppId"] = null;
                Session["IsClone"] = null;
            }
        }

        private void DataBind()
        {
            Opportunity opp = new Opportunity();
            List<Opportunity> oppList = opp.GetAllOpportunities();
            if (oppList.Count == 0)
            {
                Opportunity oppS = new Opportunity();
                oppList.Add(oppS);
                gvOpportunityNew.DataSource = oppList;
                gvOpportunityNew.DataBind();
                gvOpportunityNew.Rows[0].Visible = false;
            }
            else
            {
                gvOpportunityNew.DataSource = oppList;
                gvOpportunityNew.DataBind();
            }
        }

        protected void gvOpportunity_OnRowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lbRemove = (LinkButton)e.Row.FindControl("lnkRemove");
                Label lblStatus = ((Label)e.Row.FindControl("lblStatus"));
                string status = lblStatus.Text.Trim();
                if (status == "Open")
                    lbRemove.Text = "";
            }
        }

        protected void gvOpportunity_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            //Get the new Values.
            GridViewRow row = gvOpportunityNew.Rows[e.RowIndex];
            TextBox tbName = (TextBox)row.FindControl("tbName");
            TextBox tbLocation = (TextBox)row.FindControl("tbLocation");
            TextBox tbJobDes = (TextBox)row.FindControl("tbJobDes");
            Label lblOppId = (Label)row.FindControl("lblOppId");

            // Code to update the DataSource.
            Opportunity opp = new Opportunity();
            opp.Name = tbName.Text;
            opp.Location = tbLocation.Text;
            opp.JobDescription = tbJobDes.Text;
            opp.OpportunityId = Convert.ToInt32(lblOppId.Text);

            opp.Update();

            //Reset the edit index.
            gvOpportunityNew.EditIndex = -1;
            //Bind data to the GridView control.
            DataBind();
        }

        protected void gvOpportunity_RowEditing(object sender, GridViewEditEventArgs e)
        {
            //Set the edit index.
            gvOpportunityNew.EditIndex = e.NewEditIndex;
            //Bind data to the GridView control.
            DataBind();
        }
        protected void gvOpportunity_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            //Reset the edit index.
            gvOpportunityNew.EditIndex = -1;
            //Bind data to the GridView control.
            DataBind();
        }


   
    }
}